#version 150

#moj_import <fog.glsl>

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec4 overlayColor;
in vec2 texCoord0;
in vec4 normal;

out vec4 fragColor;

#define ALPHA_THRESHOLD 0.1
#define EMISSIVE_ALPHA 252

void main() {
    vec4 color = texture(Sampler0, texCoord0);
    if (color.a < ALPHA_THRESHOLD) {
        discard;
    }
    color *= vertexColor * ColorModulator;
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    
    if (int(round(color.a * 255)) != EMISSIVE_ALPHA) {
        color *= lightMapColor;
    }
    
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
